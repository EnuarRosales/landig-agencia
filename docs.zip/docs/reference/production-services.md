# Servicios de producción · inventario observado

> **Fuente:** `docker inspect` ejecutado en el host de producción el **2026-10-27**.
> **Alcance:** estado observado de los servicios ya desplegados. No es una guía de despliegue ni reemplaza las specs.
> **Secretos:** las credenciales, claves HMAC y contraseñas están redactadas. No se documentan valores reales.

## 1. Resumen

| Stack | Proyecto Compose | Ruta del compose | Servicios observados | Ingress público |
|---|---|---|---|---|
| Medios | `mocter-media` | `/opt/mocter-media/docker-compose.prod.yaml` | `seaweedfs`, `imgproxy` | `media.mocter.co` |
| Chatwoot | `mocter-chatwoot` | `/opt/mocter-chatwoot/docker-compose.prod.yaml` | `rails` observado; `sidekiq`, `pg-chatwoot` y `redis-chatwoot` declarados en el compose | `chatapp.mocter.co` |

Los contenedores inspeccionados **no publican puertos en el host**. El tráfico público entra exclusivamente por Traefik.

## 2. SeaweedFS

| Atributo | Valor observado |
|---|---|
| Contenedor | `mocter-media-seaweedfs-1` |
| Imagen | `chrislusf/seaweedfs:4.51` |
| Digest del manifiesto | `sha256:3a522c379599e163433a636e75022630848b63a74f08ea37bf06f8d776e9a707` |
| Estado | `running`, `healthy`, sin OOM, `RestartCount=0` |
| Comando | `weed server -dir=/data -s3 -s3.port=8333 -s3.config=/etc/seaweedfs/s3.json -master.telemetry=false` |
| Volumen | `mocter-media_seaweedfs-data` → `/data` |
| Configuración S3 | bind read-only `/opt/mocter-media/seaweedfs/s3.json` → `/etc/seaweedfs/s3.json` |
| Redes | `media_network` (172.16.5.2, alias `seaweedfs`) y `mocter-admin-prod_backend` (172.16.3.4, alias `seaweedfs`) |
| Puertos publicados | Ninguno |
| Healthcheck | `wget -q -O /dev/null http://127.0.0.1:9333/cluster/status`; intervalo 15 s, timeout 5 s, start 30 s, 10 reintentos |
| Reinicio | `unless-stopped` |
| Logs | `json-file`, 3 archivos × 10 MB |
| Límites de recursos | No observados (`Memory=0`, `NanoCpus=0`) |

**Uso desde código:** el S3 interno está en `http://seaweedfs:8333`, con path-style (`forcePathStyle: true`) y región `us-east-1`. Es alcanzable desde `media_network` y desde `mocter-admin-prod_backend`. No tiene ruta de Traefik.

**Pendiente de confirmar:** el nombre del bucket y el alcance de las credenciales están dentro de `s3.json`; no son visibles en el inspect. No asumir el bucket `mocter-media` hasta verificarlo contra la configuración real.

**Observación:** el healthcheck valida el master en `:9333`, no el gateway S3 en `:8333`. Conviene agregar un chequeo específico del S3.

## 3. imgproxy

| Atributo | Valor observado |
|---|---|
| Contenedor | `mocter-media-imgproxy-1` |
| Imagen | `ghcr.io/imgproxy/imgproxy:v4.0.20` |
| Digest del manifiesto | `sha256:33ee7afd862c4bdb96f84e25488d217aefc818c8a7fff43ede6fef66bd764b4c` |
| Estado | `running`, `healthy`, sin OOM, `RestartCount=0` |
| Redes | `media_network` (172.16.5.3, alias `imgproxy`) y `traefik_network` (172.20.0.12, alias `imgproxy`) |
| Puertos publicados | Ninguno |
| Volúmenes | Ninguno; es stateless |
| Healthcheck | `imgproxy health`; intervalo 15 s, timeout 5 s, start 10 s, 5 reintentos |
| Reinicio | `unless-stopped` |
| Logs | `json-file`, 3 archivos × 10 MB |
| Límites de recursos | No observados (`Memory=0`, `NanoCpus=0`) |

**Variables observadas (valores sensibles redactados):**

- `AWS_ACCESS_KEY_ID`, `AWS_SECRET_ACCESS_KEY`: presentes.
- `IMGPROXY_KEY`, `IMGPROXY_SALT`: presentes.
- `IMGPROXY_USE_S3=true`.
- `IMGPROXY_S3_ENDPOINT=http://seaweedfs:8333`.
- `IMGPROXY_S3_ENDPOINT_USE_PATH_STYLE=true`.
- `IMGPROXY_S3_REGION=us-east-1`.
- `IMGPROXY_BASE_URL=https://media.mocter.co`.
- `AWS_LWA_READINESS_CHECK_PATH=/health`, `AWS_LWA_INVOKE_MODE=response_stream`, `AWS_LWA_ASYNC_INIT=true` (provienen de la imagen base; no cambian el contrato en Docker).
- `IMGPROXY_MALLOC=malloc`, `VIPS_VECTOR=167772160`, `MALLOC_ARENA_MAX=2`, `VIPS_WARNING=0`.

**Etiquetas de Traefik:** router `media`, host `media.mocter.co`, entrypoint `websecure`, resolver `mytlschallenge`, service port `8080`.

**No se observaron explícitamente:** `IMGPROXY_ALLOWED_PROCESSING_OPTIONS`, `IMGPROXY_S3_ALLOWED_BUCKETS`, `IMGPROXY_WORKERS`, `IMGPROXY_MAX_SRC_RESOLUTION`, `IMGPROXY_MAX_SRC_FILE_SIZE`, `IMGPROXY_MAX_RESULT_DIMENSION` ni `IMGPROXY_MAX_ANIMATION_FRAMES`. Aplican los defaults de la imagen. Es un punto de hardening y verificación, no una suposición de que estén configurados.

## 4. Chatwoot (rails)

| Atributo | Valor observado |
|---|---|
| Contenedor | `mocter-chatwoot-rails-1` |
| Imagen | `chatwoot/chatwoot:v4.19.1` |
| Digest del manifiesto | `sha256:de91ebbe04cef408e88697ccaee44cb6f33ea87330c826880790c0eec656c610` |
| Estado | `running`, `healthy`, sin OOM, `RestartCount=0` |
| Comando | `docker/entrypoints/rails.sh bundle exec rails s -p 3000 -b 0.0.0.0` |
| Volumen | `mocter-chatwoot_storage-chatwoot` → `/app/storage` |
| Redes | `mocter-chatwoot_chatwoot_network` (172.16.4.4) y `traefik_network` (172.20.0.3) |
| Puertos publicados | Ninguno |
| Healthcheck | `GET http://127.0.0.1:3000/health`; intervalo 15 s, timeout 5 s, start 60 s, 10 reintentos |
| Reinicio | `always` |
| Logs | `json-file`, 3 archivos × 10 MB |
| Límites de recursos | No observados (`Memory=0`, `NanoCpus=0`) |

**Variables relevantes observadas:**

- `RAILS_ENV=production`, `NODE_ENV=production`, `INSTALLATION_ENV=docker`.
- `FRONTEND_URL=https://chatapp.mocter.co`, `CHATWOOT_DOMAIN=chatapp.mocter.co`.
- `POSTGRES_HOST=pg-chatwoot`, `POSTGRES_DATABASE=chatwoot`, `POSTGRES_USERNAME=chatwoot`, `POSTGRES_PORT=5432`.
- `REDIS_URL=redis://redis-chatwoot:6379`.
- `CHATWOOT_VERSION=v4.19.1`, `POSTGRES_IMAGE_TAG=pg18`, `REDIS_IMAGE_TAG=8.8.3-alpine`.
- `CW_EDITION=ee`.
- `POSTGRES_HOST_AUTH_METHOD=trust`.
- `REDIS_PASSWORD=` (vacío en el entorno de `rails`).

**Almacenamiento actual:** Chatwoot usa **volumen local** (`mocter-chatwoot_storage-chatwoot`). No hay variables `ACTIVE_STORAGE_SERVICE`, `STORAGE_*` ni bucket S3 observadas. Por lo tanto, en producción **Chatwoot no está usando SeaweedFS** para adjuntos hoy.

Chatwoot soporta ActiveStorage sobre S3-compatible, pero esa capacidad **no está activa** en este despliegue. Si se migra, debe usar un bucket separado (por ejemplo `chatwoot-attachments`), credenciales propias y la red interna de SeaweedFS; no entra en `media_catalog` ni en la cuota de producto. Validar CORS y la entrega a canales: hay casos conocidos de WhatsApp Cloud API que no aceptan URLs S3 firmadas.

**No inspeccionados:** `sidekiq`, `pg-chatwoot` y `redis-chatwoot` no forman parte de este `docker inspect`; el compose los declara. No se afirma su estado de salud ni su configuración efectiva.

## 5. Topología de redes

```text
traefik_network (ingress público)
  ├─ mocter-chatwoot-rails-1 :3000  →  chatapp.mocter.co
  └─ mocter-media-imgproxy-1 :8080  →  media.mocter.co

media_network (interno de medios)
  ├─ mocter-media-seaweedfs-1 :8333
  └─ mocter-media-imgproxy-1

mocter-admin-prod_backend (interno de la app)
  └─ mocter-media-seaweedfs-1 :8333

mocter-chatwoot_chatwoot_network (interno de Chatwoot)
  └─ mocter-chatwoot-rails-1 (y los servicios declarados en su compose)
```

**Reglas que se desprenden:**

- SeaweedFS **no** está en `traefik_network`; no recibe tráfico del navegador.
- La app accede a S3 por `mocter-admin-prod_backend` o `media_network`, no por Traefik.
- imgproxy es el único servicio de medios con ruta pública.
- Chatwoot rails está en `traefik_network` solo para el ingress de `chatapp.mocter.co`.
- Chatwoot y la app no comparten una red interna; se hablan por API HTTPS.

## 6. Contrato de integración para código

### Subida y lectura de multimedia de producto

1. El navegador sube al backend de Mocter, no a SeaweedFS.
2. El backend valida el archivo y lo escribe por S3 en `http://seaweedfs:8333`.
3. El backend registra `media_catalog` y el vínculo del producto.
4. La lectura pública se hace por `https://media.mocter.co/<firma>/...`.
5. El navegador nunca recibe `AWS_ACCESS_KEY_ID`, `AWS_SECRET_ACCESS_KEY`, `IMGPROXY_KEY` ni `IMGPROXY_SALT`.
6. El nombre del bucket se lee de configuración; no hardcodear `mocter-media` hasta confirmar el valor real en producción.

### Firma de imgproxy

- Algoritmo: HMAC-SHA256 con el par key/salt de la plataforma.
- La firma cubre el path posterior a la firma, incluidas las opciones, `plain/`, la fuente S3 y la extensión de salida.
- La fuente debe ser `s3://<bucket>/<key>` del bucket configurado en producción.
- `expires` es una opción firmada; una URL vencida responde 404.
- No se deben firmar fuentes HTTP(S) arbitrarias ni opciones fuera de la allowlist que defina la plataforma.

### Chatwoot

- Base API: `https://chatapp.mocter.co`.
- La integración es por API/SSO/webhooks; no se accede a la base PostgreSQL de Chatwoot.
- Los adjuntos de conversación **no** están en `media_catalog` y no consumen cuota de producto.
- En el estado actual, los adjuntos están en el volumen local de Chatwoot. No asumir que están en SeaweedFS.
- Si se activa ActiveStorage S3-compatible: bucket separado, credenciales separadas, `rails` y `sidekiq` en la red interna de SeaweedFS, y validación de CORS/URLs de canal.

## 7. Riesgos y verificaciones pendientes

| Tema | Estado observado | Acción recomendada |
|---|---|---|
| Adjuntos de Chatwoot | Volumen local `mocter-chatwoot_storage-chatwoot`; el `pg_dump` no los cubre | Incluirlo en el backup o migrar a S3-compatible con bucket propio |
| `POSTGRES_HOST_AUTH_METHOD` | `trust` en producción | Verificar; preferir password y red interna estricta |
| Redis de Chatwoot | `REDIS_PASSWORD` vacío en `rails` y URL sin auth | Verificar la configuración efectiva de Redis |
| `CW_EDITION` | `ee` observado | Confirmar licenciamiento; no usar capacidades enterprise |
| imgproxy | Sin allowlist, límites de workers/resolución/animación ni bucket allowlist observados | Endurecer y validar en staging |
| SeaweedFS | Healthcheck apunta al master `:9333`, no al S3 `:8333` | Agregar healthcheck del gateway S3 |
| Bucket S3 | No visible en el inspect | Confirmar en `s3.json` y en la configuración de la app |
| Límites de recursos | No observados en media ni Chatwoot | Medir y fijar límites/monitoreo |
| Digests | Tags fijados, pero no en formato `@sha256` | Evaluar pin por digest para producción |

## 8. Referencias

- [ADM-001 · diseño §11.6](../specs/adm-001-mocter-admin/design.md)
- [DAT-001 · diseño §2](../specs/dat-001-arquitectura-datos-multiinquilino/design.md)
- [OPS-001 · diseño §7.8 y §9](../specs/ops-001-operacion-continuidad-observabilidad/design.md)
- [CHW-001 · inventario de Chatwoot](chatwoot/README.md)
